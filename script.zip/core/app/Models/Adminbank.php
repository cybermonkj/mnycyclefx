<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Adminbank extends Model {
    protected $table = "admin_bank";
    protected $guarded = [];
}
