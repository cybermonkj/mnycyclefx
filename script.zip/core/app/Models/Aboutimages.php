<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Aboutimages extends Model {
    protected $table = "about_images";
    protected $guarded = [];
}
