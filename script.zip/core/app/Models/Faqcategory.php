<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Faqcategory extends Model {
    protected $table = "faq_cat";
    protected $guarded = [];
}
