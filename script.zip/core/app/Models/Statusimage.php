<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Statusimage extends Model {
    protected $table = "status_images";
    protected $guarded = [];
}
