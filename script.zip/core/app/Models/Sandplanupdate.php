<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Sandplanupdate extends Model {
    protected $table = "sand_plan_updates";
    protected $guarded = [];
}
